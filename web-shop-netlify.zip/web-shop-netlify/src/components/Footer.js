import React from 'react'

function Footer() {
  return (
    <div className='footer fixed-bottom'>
      <p>Designed and Developed by</p>
      <hr/>
      <p>Zvonimir Madarac</p>
    </div>
  )
}

export default Footer

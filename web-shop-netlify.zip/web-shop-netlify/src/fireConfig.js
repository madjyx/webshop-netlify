import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyD3nqSoLr_IFqrFNDrIQIy1AJmHPLGCgZc",
  authDomain: "web-shop-a9274.firebaseapp.com",
  projectId: "web-shop-a9274",
  storageBucket: "web-shop-a9274.appspot.com",
  messagingSenderId: "1019335213619",
  appId: "1:1019335213619:web:d6be8f6b56f0708b75d946",
  measurementId: "G-FPEQ5HDFV6"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

const fireDB = getFirestore(app)

export default fireDB
export const fireproducts = [
	{
		"price": 49.99,
		"name": "Smart hub",
		"description": "smart device",
		"category": "electronics",
		"imageURL": "https://www.powerplanetonline.com/cdnassets/xiaomi_mi_smart_home_hub_01_l.jpg",
	},
	{
		"price": 24.99,
		"name": "Motion sensor",
		"description": "EATON Lighting MS180 180 Degree Replacement Motion Security Floodlight Sensor, Bronze",
		"category": "electronics",
		"imageURL": "https://m.media-amazon.com/images/I/41QHDdV5lgL._AC_SL1000_.jpg",
	},
	{
		"price": 99.99,
		"name": "Wireless camera",
		"description": "LongPlus Wireless Outdoor Security Camera, Battery Powered Cameras for Home Security Wireless WiFi with Night Vision, Motion Detection,Siren Alarm,Spotlight,2Way Audio, Weatherproof,SD/Cloud(White)",
		"category": "electronics",
		"imageURL": "https://m.media-amazon.com/images/I/6154jKAoyRL._AC_SL1500_.jpg",
	},
	{
		"price": 19.99,
		"name": "Smoke sensor",
		"description": "X-Sense Smoke Detector Alarm, 10 Years Battery-Operated Smoke and Fire Alarm with Photoelectric Sensor, Compliant with UL 217 Standard, SD06 (Not Hardwired)",
		"category": "electronics",
		"imageURL": "https://m.media-amazon.com/images/I/41YAwQLYOtL._AC_.jpg",
	},
	{
		"price": 14.99,
		"name": "Water leak sensor",
		"description": "4 Pack Water Leak Detector - 95 dB Flood Detection Alarm Sensor for Bathrooms, Basements, Laundry Rooms, Garages, Attics and Kitchens by Mindful Design (Black)",
		"category": "electronics",
		"imageURL": "https://m.media-amazon.com/images/I/71ieb3owKoL._AC_SL1500_.jpg",
	},
]